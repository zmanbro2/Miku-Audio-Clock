This is just a simple program that runs in the systemtray and has Hatsune Miku say the hour every hour
https://youtu.be/5Sam1UBtL4U

decided to put it here so people can use it if they like

i'm very new to programming so my code might be a bit bad lol
the program is simple enough that i dont think it matters that much 
criticism is always welcome though 
 
Miku voice provided by u/Kenshin90991 on reddit 